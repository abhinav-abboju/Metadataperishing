﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using Microsoft.SharePoint.Client;
using SP = Microsoft.SharePoint.Client;
using System.IO;

namespace ExportSPContent
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                NetworkCredential credentials = new NetworkCredential(Constants.UserName, Constants.Password, Constants.Domain);

                string csvDataHeaders = "Landingzone_Filepath,Hash, Filepath_Source,Filename_Source,Source_System_Source,BNYM_LOB_Source,Unique_DocumentID_Source,ContractType_Source,Agreement_Type_Source,Contract_Status_Source,StartDate_Source, TerminationDate_Source,Signed_Source,Governing_Law_Source,Non_BNYM_Entity_Legal_Entity_Source,ContractingParties_Source,CID_Source,Client_Domicile_Source, Special_Status_Source,Address_Line_1_Source,Address_Line_2_Source,Address_Line_3_Source,Address_City_Source,	Address_State_Province_Region_Code_Source,Address_Postal_Code_Source,Address_Country_Source,Non_BNYM_Capacity_Source,InternalContractingParty_Source,BNYM_MLE_Code_Source";

                ExportContent export = new ExportContent();

                string[] sitesInfo = System.IO.File.ReadAllLines(@Constants.SitesInfoFileLocation);
                foreach (string siteInfo in sitesInfo)
                {
                    try
                    {
                        string sNo = siteInfo.Split(',')[0].Trim();
                        string siteUrl = siteInfo.Split(',')[1].Trim();
                        string listName = siteInfo.Split(',')[2].Trim();
                        string listURLName = siteInfo.Split(',')[3].Trim();
                        string listType = siteInfo.Split(',')[4].Trim();
                        string excelExportFilePath = Constants.ExcelExportFilesLocation + sNo + "_" + listName.Replace(' ', '_') + "_" + DateTime.Now.Year.ToString() + "_" + DateTime.Now.Month.ToString() + "_" + DateTime.Now.Day.ToString() + ".csv";

                        Console.WriteLine("");
                        Console.WriteLine("Site URL:" + siteUrl);

                        string category = listType.ToLower();

                        if (category == "list")
                        {
                            if (sNo == "1")
                            {
                                export.ExportList1_GCMContracts(credentials, sNo, siteUrl, listName, listURLName, excelExportFilePath, csvDataHeaders);
                            }
                            else if (sNo == "2")
                            {
                                export.ExportList2_GLSContracts(credentials, sNo, siteUrl, listName, listURLName, excelExportFilePath, csvDataHeaders);
                            }
                        }
                        else
                        {
                            export.ExportLibrary(credentials, sNo, siteUrl, listName, listURLName, excelExportFilePath, csvDataHeaders);
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error in sites foreach: " + ex.Message);
                    }
                }
                Console.ReadLine();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error in reading sites info: " + ex.Message);
            }
        }
    }
}
