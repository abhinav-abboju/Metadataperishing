﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace ExportSPContent
{
    class Constants
    {
        public static string UserName = ConfigurationManager.AppSettings["LoginUserName"].ToString();
        public static string Password = ConfigurationManager.AppSettings["LoginUserPassword"].ToString();
        public static string Domain = ConfigurationManager.AppSettings["LoginUserDomain"].ToString();
        public static string SitesInfoFileLocation = ConfigurationManager.AppSettings["SitesInfoFileLocation"].ToString();
        public static string ExcelExportFilesLocation = ConfigurationManager.AppSettings["ExcelExportFilesLocation"].ToString();
        public static string AttachmentExportFilesLocation = ConfigurationManager.AppSettings["AttachmentExportFilesLocation"].ToString();

        public static string GlobalBDS_Open_US_Folderpath = "/sites/bdsmarcomm/GlobalBDS/Open/US/";
    }
}
