﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using Microsoft.SharePoint.Client;
using SP = Microsoft.SharePoint.Client;
using System.IO;

namespace ExportSPContent
{
    class ExportContent
    {
        public void ExportList1_GCMContracts(NetworkCredential credentials, string sNo, string siteUrl, string listName, string listURLName, string excelExportFilePath, string csvDataHeaders)
        {
            var csvData = new StringBuilder();

            using (ClientContext clientContext = new ClientContext(siteUrl))
            {
                clientContext.Credentials = credentials;

                //Get the Site Collection
                Site oSite = clientContext.Site;
                clientContext.Load(oSite);
                clientContext.ExecuteQuery();

                Web oWeb = clientContext.Web;
                clientContext.Load(oWeb);
                clientContext.ExecuteQuery();

                SP.List oList = oWeb.Lists.GetByTitle(listName);

                CamlQuery camlQuery = new CamlQuery();
                camlQuery.ViewXml = "<View><Query><Where><Geq><FieldRef Name='Modified'/><Value Type='DateTime'><Today IncludeTimeValue='TRUE' OffsetDays='-1' /></Value></Geq></Where></Query></View>";
                ListItemCollection collListItem = oList.GetItems(camlQuery);

                clientContext.Load(collListItem, items => items.Include(
                     item => item.Id,
                     item => item["Title"], item => item["Title_x0020_of_x0020_agreement"],
                     item => item["Type_x0020_of_x0020_agreement"],
                     item => item["Contract_x0020_Status"], item => item["Date_x0020_of_x0020_contract"],
                     item => item["Date_x0020_of_x0020_last_x0020_e"],
                     item => item["Governing_x0020_law"], item => item["Client_x0020_Name_x0020__x0028_c"],
                     item => item["Client_x0020_Name_x0028_as_x0020"],
                     item => item["Corporate_x0020_identifier_x0020"], item => item["Onboarding_x0020_Region"],
                     item => item["MiFID_x0020_Classification"],
                     item => item["Address_x0020_2"], item => item["Address_x0020_3"],
                     item => item["Address_x0020_4"], item => item["Address_x0020_5"],
                     item => item["State_x0020__x002f__x0020_County"], item => item["Postal_x0020_Code"], item => item["Country"],
                     item => item["Exact_x0020_names_x0020_of_x0020"], item => item["BNYM_x0020_Legal_x0020_Entity_x0"],
                     item => item["Modified"],
                     item => item["Created"], item => item["Author"], item => item["Editor"]
                    ));

                clientContext.ExecuteQuery();

                csvData.AppendLine(csvDataHeaders);

                Console.WriteLine("Number of documents found: " + collListItem.Count());

                foreach (ListItem oListItem in collListItem)
                {
                    Folder folder = oWeb.GetFolderByServerRelativeUrl(siteUrl + "Lists/" + listURLName + "/Attachments/" + oListItem.Id.ToString());

                    clientContext.Load(folder);

                    try
                    {
                        clientContext.ExecuteQuery();
                    }
                    catch (ServerException ex)
                    {
                        Console.WriteLine(ex.Message);
                        Console.WriteLine("No Attachment for ID " + oListItem.Id.ToString());
                    }

                    FileCollection attachments = folder.Files;
                    clientContext.Load(attachments);
                    clientContext.ExecuteQuery();

                    foreach (Microsoft.SharePoint.Client.File oFile in folder.Files)
                    {
                       // Console.WriteLine("Found Attachment for ID " + oListItem.Id.ToString());

                        FileInfo myFileinfo = new FileInfo(oFile.Name);
                        WebClient client1 = new WebClient();
                        client1.Credentials = credentials;

                        //Console.WriteLine("Downloading " + oFile.ServerRelativeUrl);

                        byte[] fileContents = client1.DownloadData(siteUrl.ToLower().Split(new string[] { "/sites/" }, StringSplitOptions.None)[0] + oFile.ServerRelativeUrl);

                        FileStream fStream = new FileStream(@Constants.AttachmentExportFilesLocation + sNo + "_" + listName.Replace(' ', '_') + "/" + oFile.Name, FileMode.Create);

                        fStream.Write(fileContents, 0, fileContents.Length);
                        fStream.Close();

                        csvData.AppendLine(string.Format("\"{0}\",\"{1}\",\"{2}\",\"{3}\",\"{4}\",\"{5}\",\"{6}\",\"{7}\",\"{8}\",\"{9}\",\"{10}\",\"{11}\",\"{12}\",\"{13}\",\"{14}\",\"{15}\",\"{16}\",\"{17}\",\"{18}\",\"{19}\",\"{20}\",\"{21}\",\"{22}\",\"{23}\",\"{24}\",\"{25}\",\"{26}\",\"{27}\",\"{28}\"",
                        @Constants.AttachmentExportFilesLocation + sNo + "_" + listName.Replace(' ', '_') + "\\" + oFile.Name,
                        string.Empty,
                        siteUrl.ToLower().Split(new string[] { "/sites/" }, StringSplitOptions.None)[0] + oFile.ServerRelativeUrl,
                        oFile.Name,
                        "SP", "Liquidity Services",
                        oListItem["Title"],
                        oListItem["Title_x0020_of_x0020_agreement"],
                        oListItem["Type_x0020_of_x0020_agreement"],
                           oListItem["Contract_x0020_Status"],
                           oListItem["Date_x0020_of_x0020_contract"],
                           oListItem["Date_x0020_of_x0020_last_x0020_e"],
                          "",
                           oListItem["Governing_x0020_law"],
                           oListItem["Client_x0020_Name_x0020__x0028_c"],
                           oListItem["Client_x0020_Name_x0028_as_x0020"],
                           oListItem["Corporate_x0020_identifier_x0020"],
                           oListItem["Onboarding_x0020_Region"],
                           ("MiFiD Classification - " + oListItem["MiFID_x0020_Classification"]),
                           oListItem["Address_x0020_2"],
                           oListItem["Address_x0020_3"],
                           oListItem["Address_x0020_4"],
                           oListItem["Address_x0020_5"],
                           oListItem["State_x0020__x002f__x0020_County"],
                           oListItem["Postal_x0020_Code"],
                           oListItem["Country"],
                           "N/A",
                           oListItem["Exact_x0020_names_x0020_of_x0020"],
                           oListItem["BNYM_x0020_Legal_x0020_Entity_x0"]));
                    }
                }
            }
            System.IO.File.WriteAllText(@excelExportFilePath, csvData.ToString());

        }
        public void ExportList2_GLSContracts(NetworkCredential credentials, string sNo, string siteUrl, string listName, string listURLName, string excelExportFilePath, string csvDataHeaders)
        {
            var csvData = new StringBuilder();

            using (ClientContext clientContext = new ClientContext(siteUrl))
            {
                clientContext.Credentials = credentials;

                //Get the Site Collection
                Site oSite = clientContext.Site;
                clientContext.Load(oSite);
                clientContext.ExecuteQuery();

                Web oWeb = clientContext.Web;
                clientContext.Load(oWeb);
                clientContext.ExecuteQuery();

                SP.List oList = oWeb.Lists.GetByTitle(listName);

                CamlQuery camlQuery = new CamlQuery();
                camlQuery.ViewXml = "<View><Query><Where><Geq><FieldRef Name='Modified'/><Value Type='DateTime'><Today IncludeTimeValue='TRUE' OffsetDays='-1' /></Value></Geq></Where></Query></View>";
                ListItemCollection collListItem = oList.GetItems(camlQuery);

                clientContext.Load(collListItem, items => items.Include(
                   item => item.Id,
                   item => item["Title"],
                        item => item["Title_x0020_of_x0020_agreement_x"],
                        item => item["Type_x0020_of_x0020_agreement"],
                           item => item["Status"],
                           item => item["Date_x0020_of_x0020_contract"],
                           item => item["Terminated_x0020_Date"],
                           item => item["Contract_x0020_Executed"],
                           item => item["Governing_x0020_law"],
                           item => item["Names_x0020_of_x0020_other_x00200"],
                           item => item["Client_x0020_Contracting_x0020_L"],
                           item => item["Corporate_x0020_identifier_x00200"],
                           item => item["Region"],
                           item => item["MiFiD_x0020_Classification"],
                           item => item["Address_x0020_1"],
                           item => item["Address_x0020_2"],
                           item => item["Address_x0020_3"],
                           item => item["City"],
                           item => item["State_x0020__x002f__x0020_County"],
                           item => item["Postal_x0020_Code"],
                           item => item["State_x0020__x002f__x0020_County"],
                           item => item["Exact_x0020_names_x0020_of_x0020"],
                           item => item["Legal_x0020_Entity_x0020_ID"],
                     item => item["Modified"],
                     item => item["Created"], item => item["Author"], item => item["Editor"]
                    ));

                clientContext.ExecuteQuery();

                csvData.AppendLine(csvDataHeaders);

                Console.WriteLine("Number of documents found: " + collListItem.Count());

                foreach (ListItem oListItem in collListItem)
                {
                    Folder folder = oWeb.GetFolderByServerRelativeUrl(siteUrl + "Lists/" + listURLName + "/Attachments/" + oListItem.Id.ToString());

                    clientContext.Load(folder);

                    try
                    {
                        clientContext.ExecuteQuery();
                    }
                    catch (ServerException ex)
                    {
                        Console.WriteLine(ex.Message);
                        Console.WriteLine("No Attachment for ID " + oListItem.Id.ToString());
                    }

                    FileCollection attachments = folder.Files;
                    clientContext.Load(attachments);
                    clientContext.ExecuteQuery();

                    foreach (Microsoft.SharePoint.Client.File oFile in folder.Files)
                    {
                        //Console.WriteLine("Found Attachment for ID " + oListItem.Id.ToString());

                        FileInfo myFileinfo = new FileInfo(oFile.Name);
                        WebClient client1 = new WebClient();
                        client1.Credentials = credentials;

                        //Console.WriteLine("Downloading " + oFile.ServerRelativeUrl);

                        byte[] fileContents = client1.DownloadData(siteUrl.ToLower().Split(new string[] { "/sites/" }, StringSplitOptions.None)[0] + oFile.ServerRelativeUrl);

                        FileStream fStream = new FileStream(@Constants.AttachmentExportFilesLocation + sNo + "_" + listName.Replace(' ', '_') + "/" + oFile.Name, FileMode.Create);

                        fStream.Write(fileContents, 0, fileContents.Length);
                        fStream.Close();

                        csvData.AppendLine(string.Format("\"{0}\",\"{1}\",\"{2}\",\"{3}\",\"{4}\",\"{5}\",\"{6}\",\"{7}\",\"{8}\",\"{9}\",\"{10}\",\"{11}\",\"{12}\",\"{13}\",\"{14}\",\"{15}\",\"{16}\",\"{17}\",\"{18}\",\"{19}\",\"{20}\",\"{21}\",\"{22}\",\"{23}\",\"{24}\",\"{25}\",\"{26}\",\"{27}\",\"{28}\"",
                        @Constants.AttachmentExportFilesLocation + sNo + "_" + listName.Replace(' ', '_') + "\\" + oFile.Name,
                        string.Empty,
                        siteUrl.ToLower().Split(new string[] { "/sites/" }, StringSplitOptions.None)[0] + oFile.ServerRelativeUrl,
                        oFile.Name,
                        "SP", "Liquidity Services",
                        oListItem["Title"],
                        oListItem["Title_x0020_of_x0020_agreement_x"],
                        oListItem["Type_x0020_of_x0020_agreement"],
                           oListItem["Status"],
                           oListItem["Date_x0020_of_x0020_contract"],
                           oListItem["Terminated_x0020_Date"],
                           oListItem["Contract_x0020_Executed"],
                           oListItem["Governing_x0020_law"],
                           oListItem["Names_x0020_of_x0020_other_x00200"],
                           oListItem["Client_x0020_Contracting_x0020_L"],
                           oListItem["Corporate_x0020_identifier_x00200"],
                           oListItem["Region"],
                           ("MiFiD Classification - " + oListItem["MiFiD_x0020_Classification"]),
                           oListItem["Address_x0020_1"],
                           oListItem["Address_x0020_2"],
                           oListItem["Address_x0020_3"],
                           oListItem["City"],
                           oListItem["State_x0020__x002f__x0020_County"],
                           oListItem["Postal_x0020_Code"],
                           oListItem["State_x0020__x002f__x0020_County"],
                           "N/A",
                           oListItem["Exact_x0020_names_x0020_of_x0020"],
                           oListItem["Legal_x0020_Entity_x0020_ID"]));
                    }
                }
            }
            System.IO.File.WriteAllText(@excelExportFilePath, csvData.ToString());
        }

        public void ExportLibrary(NetworkCredential credentials, string sNo, string siteUrl, string listName, string listURLName, string excelExportFilePath, string csvDataHeaders)
        {
            var csvData = new StringBuilder();

            using (ClientContext clientContext = new ClientContext(siteUrl))
            {
                clientContext.Credentials = credentials;

                //Get the Site Collection
                Site oSite = clientContext.Site;
                clientContext.Load(oSite);
                clientContext.ExecuteQuery();

                Web oWeb = clientContext.Web;
                clientContext.Load(oWeb);
                clientContext.ExecuteQuery();

                SP.List oList = oWeb.Lists.GetByTitle(listName);

                CamlQuery camlQuery = new CamlQuery();
                camlQuery.ViewXml = "<View Scope='RecursiveAll'><Query><Where><And><Geq><FieldRef Name='Modified'/><Value Type='DateTime'><Today IncludeTimeValue='TRUE' OffsetDays='-1' /></Value></Geq><Contains><FieldRef Name='FileLeafRef'/><Value Type='Text'>.pdf</Value></Contains></And></Where></Query></View>";
                if (Convert.ToInt32(sNo) == 10)
                    camlQuery.FolderServerRelativeUrl = Constants.GlobalBDS_Open_US_Folderpath;

                ListItemCollection collListItem = oList.GetItems(camlQuery);

                clientContext.Load(collListItem, items => items.Include(
                   item => item["Title"], item => item["Modified"], item => item.File
                ));
                clientContext.ExecuteQuery();

                csvData.AppendLine(csvDataHeaders);

                Console.WriteLine("Number of documents found: " + collListItem.Count());

                foreach (ListItem oListItem in collListItem)
                {
                    SP.File file = oListItem.File;
                    if (file != null)
                    {
                        string fileRef = oListItem.File.ServerRelativeUrl;
                        FileInformation fileInfo = SP.File.OpenBinaryDirect(clientContext, fileRef.ToString());

                        var fileName = Path.Combine(@Constants.AttachmentExportFilesLocation + sNo + "_" + listName.Replace(' ', '_') + "/", (string)oListItem.File.Name);
                        using (var fileStream = System.IO.File.Create(fileName))
                        {
                            fileInfo.Stream.CopyTo(fileStream);
                        }

                        csvData.AppendLine(string.Format("\"{0}\",\"{1}\",\"{2}\",\"{3}\",\"{4}\",\"{5}\",\"{6}\",\"{7}\",\"{8}\",\"{9}\",\"{10}\",\"{11}\",\"{12}\",\"{13}\",\"{14}\",\"{15}\",\"{16}\",\"{17}\",\"{18}\",\"{19}\",\"{20}\",\"{21}\",\"{22}\",\"{23}\",\"{24}\",\"{25}\",\"{26}\",\"{27}\",\"{28}\"",
                        @Constants.AttachmentExportFilesLocation+ sNo + "_" + listName.Replace(' ', '_') + "\\" + file.Name.ToString(),
                        string.Empty,
                        siteUrl.ToLower().Split(new string[] { "/sites/" }, StringSplitOptions.None)[0] + file.ServerRelativeUrl,
                        file.Name.ToString(),
                        "SP", "Liquidity Services",
                        oListItem["Title"],
                        string.Empty,
                        string.Empty,
                           string.Empty,
                           string.Empty,
                           string.Empty,
                          "Not Found",
                           string.Empty,
                           string.Empty,
                           string.Empty,
                           string.Empty,
                           string.Empty,
                           ("MiFiD Classification - " + string.Empty),
                           string.Empty,
                           string.Empty,
                           string.Empty,
                           string.Empty,
                           string.Empty,
                           string.Empty,
                           string.Empty,
                           "N/A",
                           string.Empty,
                           string.Empty));
                    }

                }
            }
            System.IO.File.WriteAllText(@excelExportFilePath, csvData.ToString());
        }

    }
}
